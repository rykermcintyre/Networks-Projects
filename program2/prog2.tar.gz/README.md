File Names:
	/clientdir/client.c
	/clientdir/Makefile
	/serverdir/server.c
	/serverdir/Makefile

Inside both directories run make to get the executables.
To run the server, ./myftpd [Port]
To run the client, ./myftp serverName [Port]

Note: Hope you have a nice day.
